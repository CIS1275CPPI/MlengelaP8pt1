#ifndef FUNCTIONS_H
#  define FUNCTIONS_H

   #include <cstdint>
   #include <string>

   using std::string;

   bool getRowsAndColumns(const string &fileName, int *rowsPtr, int *columnsPtr, string &errMsg);
   void getValues(const string &line, string *theValues);
   string addCommas(int64_t value);

#endif
