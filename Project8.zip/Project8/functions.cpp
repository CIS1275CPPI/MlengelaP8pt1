// ---------------------------------
// System Headers
// ---------------------------------

#include <sstream>
#include <fstream>

// ---------------------------------
// Local Headers
// ---------------------------------

#include "functions.h"

// ---------------------------------
// getRowsAndColumns
// ---------------------------------

bool getRowsAndColumns(const string &fileName, int *rowsPtr, int *columnsPtr, string &errMsg)
{
   *rowsPtr = *columnsPtr = 0;

   std::ifstream in(fileName);

   if(!in)
   {
      errMsg = "Could not open file: [" + fileName + "]";
      return(false);
   }

   string line;

   while(getline(in, line))
   {
      if(*columnsPtr == 0)
      {
         int nCommas = 0;

         for(char c : line)
            if(c == ',')
               nCommas++;

         *columnsPtr = nCommas + 1;
      }

      ++(*rowsPtr);
   }

   return(true);
}

// ---------------------------------
// getValues
// ---------------------------------

void getValues(const string &line, string *theValues)
{
   string current;

   for(size_t i = 0, j = 0; i < line.size(); i ++)
   {
      if(line[i] != ',')
      {
         current += line[i];

         if(i + 1 == line.size() || line[i + 1] == ',')
         {
            theValues[j++] = current;
            current = "";
         }
      }
   }
}

// ---------------------------------
// addCommas
// ---------------------------------


string addCommas(int64_t value)
{
   std::ostringstream out;

   out << value;

   string s = out.str();
   string result;

   for(int i = s.size() - 1, j = 1; i >= 0; i --, j ++)
   {
      result = s[i] + result;

      if(j % 3 == 0 && i > 0)
         result = "," + result;
   }

   return(result);
}