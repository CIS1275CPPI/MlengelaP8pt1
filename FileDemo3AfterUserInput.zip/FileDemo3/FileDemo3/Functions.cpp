// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date:8 Nov 2021 
// Purpose: Function definitions for FileDemo3

#include "Functions.h"
using namespace std;

void DisplayHeader()
{
	cout << "Welcome to supper inventory manager 3000!" << endl;
	cout << "The best inventory manager in the multiverse!" << endl;
	cout << endl;
}

void GetInventoryFromUser(
	vector<string>& rDescriptions, vector<int>& rQuantity,
	vector<string>& rLocation, vector<float>& rLength,
	vector<float>& rWidth, vector<float>& rDepth,
	vector<float>& rThickness, vector<string>& rType)
{
	//Start a loop
	do {
		string description;
		cout << "Description: ";
		getline(cin, description);
		rDescriptions.push_back(description);

		int quantity;
		cout << "Quantity: ";
		cin >> quantity;
		rQuantity.push_back(quantity);
		cin.ignore();

		string location;
		cout << "Location: ";
		getline(cin, location);
		rLocation.push_back(location);
		
		float length;
		cout << "Length: ";
		cin >> length;
		rLength.push_back(length);

		float width;
		cout << "Width: ";
		cin >> width;
		rWidth.push_back(width);

		float depth;
		cout << "Depth: ";
		cin >> depth;
		rDepth.push_back(depth);

		float thickness;
		cout << "Thickness: ";
		cin >> thickness;
		rThickness.push_back(thickness);
		cin.ignore();

		string type;
		cout << "Type: ";
		getline(cin, type);
		rType.push_back(type);
	} while (DoAnother());
}

bool DoAnother()
{
	string doAnother;
	cout << "Do another (y/n)? ";
	getline(cin, doAnother);
	return tolower(doAnother[0]) == 'y';
}


void DisplayGoodbye()
{
	cout << "Thank you for using supper inventory manager 3000!" << endl;
}

