// Functions.h 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date:8 Nov 2021 
// Purpose: Function declarations for FileDemo3

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <vector>
#include <string>
using namespace std;

void DisplayHeader();
void GetInventoryFromUser(
	vector<string>& rDescriptions, vector<int>& rQuantity,
	vector<string>& rLocation, vector<float>& rLength,
	vector<float>& rWidth, vector<float>& rDepth,
	vector<float>& rThickness, vector<string>& rType);
bool DoAnother();
void DisplayGoodbye();

#endif // !_FUNCTIONS_H

