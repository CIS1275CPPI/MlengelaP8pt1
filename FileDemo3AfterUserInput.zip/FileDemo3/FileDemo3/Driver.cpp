// .cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date:8 Nov 2021 
// Purpose: 

#include "Functions.h"
using namespace std;

int main()
{
    //Declare vectors
    vector<string> descriptions;
    vector<int> quantity;
    vector<string> location;
    vector<float> length;
    vector<float> width;
    vector<float> depth;
    vector<float> thickness;
    vector<string> type;

    //Display header
    DisplayHeader();

    //Get inventory items from user 
    GetInventoryFromUser(descriptions, quantity, location, length, width, depth, thickness, type);

    //Write inventory items to file

    //Open file and read inventory items

    //Display inventory items

    //Say goodbye
    DisplayGoodbye();

    return 0;
}