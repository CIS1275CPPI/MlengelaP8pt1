#include "Functions.h"


void WriteHeader()
{
	cout << "\n This is a program that will read data on New Mexico Population by county "
		<< "\n from 2010 to 2019. It will calculate the counties with the "
		<< "\n largest and smallest increase and decrease in population in the time period.\n";
}

void Goodbye()
{
	cout << "\n\n Goodbye - hope you enjoyed our population information! " << endl << endl;
}

bool ReadFile(int res10[], int res19[], string name[])
{
	ifstream input{ FILENAME.c_str() };
	if (!input)
	{
		return false;
	}

	string trash, temp;
	//Throw away the first 5 lines
	for (int i{ 0 }; i < 5; ++i)
	{
		getline(input, trash);
	}
	for (int x{ 0 }; x < SIZE; ++x)
	{
		//Read the .
		getline(input, trash, '.');

		//Read the county name
		getline(input, name[x], ',');

		//throw away the New Mexico and the next column
		for (int y{ 0 }; y < 2; ++y)
		{
			getline(input, trash, ',');
		}
		//Read column D
		getline(input, temp, ',');
		res10[x] = atoi(temp.c_str());

		//throw away the next eight columns
		for (int y{ 0 }; y < 8; ++y)
		{
			getline(input, trash, ',');
		}
		//read column M
		getline(input, temp);
		res19[x] = atoi(temp.c_str());

	}
	return true;
}

void Analyze(int res10[], int res19[], PopulationResults& result)
{
	//create local array
	int tempArray[SIZE];


	//Get the difference between the years
	for (int i{ 0 }; i < SIZE; ++i)
	{
		tempArray[i] = res19[i] - res10[i];
	}

	//for (int i : tempArray)
	//	cout << "\n " << i;
	//Find largest increase and smallest increase

	result.largestInc = 0;
	result.smallestInc = 20000;
	for (int i{ 1 }; i < SIZE; ++i)
	{
		if (tempArray[i] >= result.largestInc)
		{
			result.largestInc = tempArray[i];
			result.largestDecIndex = i;
		}
		else if (tempArray[i] > 0 &&
			tempArray[i] < result.smallestInc)
		{
			result.smallestInc = tempArray[i];
			result.smallestIncIndex = i;
		}
	}

	//Find largest decrease and  smallest decrease
	result.largestDec = 0;
	result.smallestDec = -20000;
	for (int i{ 1 }; i < SIZE; ++i)
	{
		if (tempArray[i] <= result.largestDec)
		{
			result.largestDec = tempArray[i];
			result.largestDecIndex = i;
		}
		else if (tempArray[i] < 0 &&
			tempArray[i] > result.smallestDec)
		{
			result.smallestDec = tempArray[i];
			result.smallestdecIndex = i;
		}
	}
}

bool WriteReport(PopulationResults& result, string name[])
{
	ofstream output(OUTPUTFILE);
	if (!output)
		return false;
	else
	{
		output << "\n This is a program that will read data on New Mexico "
			<< " Population by county \n from 2010 to 2019. "
			<< " Here are the counties with the largest and smallest"
			<< "\n increase and decrease in population in the time period.";		     
		output << "\n\n The largest Increase in population is "
			<< result.largestInc << " in " << name[result.largestIncIndex]
			<< "\n The smallest Increase in population is "
			<< result.smallestInc << " in " << name[result.smallestIncIndex]
			<< "\n The largest Decrease in population is "
			<< result.largestDec << " in " << name[result.largestDecIndex]
			<< "\n The smallest decrease in Population is "
			<< result.smallestDec << " in " << name[result.smallestdecIndex];

		output.close();
		return true;
	}
}
