/*********************************************************************************
* Program: Reading files and outpur
* Programmer: Daudi Mlengela
* Date:
* Purpose: 
**********************************************************************************/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string>
#include <fstream>
#include <iostream>
using namespace std;

const int SIZE{ 33 };
const string FILENAME{ "co-est2019-annres-35.csv" };
const string OUTPUTFILE{ "Output Report.txt" };

struct PopulationResults
{
	int largestInc{ 0 };
	int largestIncIndex{ 0 };
	int smallestInc{ 0 };
	int smallestIncIndex{ 0 };
	int largestDec{ 0 };
	int largestDecIndex{ 0 };
	int smallestDec{ 0 };
	int smallestdecIndex{ 0 };

};

void WriteHeader();
void Goodbye();
bool ReadFile(int res10[], int res19[], string name[]);
void Analyze(int res10[], int res19[], PopulationResults& result);
bool WriteReport(PopulationResults & result, string name[])

#endif


