#include "Functions.h"

int main()
{

	WriteHeader();
	string  name[SIZE];
	int res2010[SIZE], res2019[SIZE];
	int largestIncrease{ 0 }, smallestIncrease{ 0 };
	int largestDecrease{ 0 }, smallestDecrease{ 0 };
	PopulationResults result;

	//Call the read function
	bool bRead = ReadFile(res2010, res2019, name);
	if (bRead)
	{
		Analyze(res2010, res2019, result);
		for (auto i : res2019)
			cout << "\n " << i;

		bool bWrote = WriteReport(result, name);
		if (!bWrote)
		{
			cout << "\n Sorry, no file written";
		}
		else
		{
			cout << "\n Your report was written into this file: "
				<< OUTPUTFILE;
		}

	}

	Goodbye();
	return 0;
}
