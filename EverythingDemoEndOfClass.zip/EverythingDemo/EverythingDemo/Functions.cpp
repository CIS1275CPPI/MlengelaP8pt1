// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 15 Nov 2021
// Purpose: Function Definitions

#include "Functions.h"
using namespace std;

//Get names from user
void GetNames(string names[], int &rCount)
{
	rCount = 0;
	string name;
	do
	{
		name = AskForNameFromUser();
		if (name != "")
		{
			names[rCount] = name;
			rCount++;
		}
	} while (name != "");
}

//Get Names from file
void GetNames(string names[], int& rCount, string fileName)
{
	//Open the file
	ifstream inFile;
	inFile.open(fileName);

	//Read in the names
	if (inFile.is_open())
	{
		rCount = 0;
		string text;
		while (getline(inFile, text))
		{
			names[rCount] = text;
			rCount++;
		}
	}


	//Close the file
}

//Ask for your name
string AskForNameFromUser()
{
	string name;
	cout << "Please enter name (or enter to quit): ";
	getline(cin, name);
	return name;
}

