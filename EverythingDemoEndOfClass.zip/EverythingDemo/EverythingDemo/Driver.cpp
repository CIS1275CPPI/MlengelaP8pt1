// Driver.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 15 Nov 2021
// Purpose: demo stuff

#include "Functions.h"
using namespace std;

int main()
{
    //Declare an array to keep names
    string names[SIZE];
    int count;

    //Ask user to get names by keyboard or file
    cout << "(T)ype names in or read from (F)ile? ";
    char option;
    cin >> option;
    cin.ignore();
    switch (option)
    {
    case 'T':
    case't':
        //Fill array with names from user
        GetNames(names, count);
        break;
    case 'F':
    case'f':
        string fileName;
        cout << "Please enter file name: ";
        getline(cin, fileName);
        GetNames(names, count, fileName);
    }

    

    //Display names
    for (int i = 0; i < count; ++i)
    {
        cout << names[i] << endl;
    }

    return 0;
}