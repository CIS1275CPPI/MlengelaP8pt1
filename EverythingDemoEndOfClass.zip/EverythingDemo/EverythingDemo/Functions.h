// Functions.h 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 15 Nov 2021
// Purpose: Function Declarations

//Inclusde guard only compile one time
#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

const int SIZE = 10;

string AskForNameFromUser();
void GetNames(string names[], int& rCount);
void GetNames(string names[], int& rCount, string fileName);

#endif // !_FUNCTIONS_H
