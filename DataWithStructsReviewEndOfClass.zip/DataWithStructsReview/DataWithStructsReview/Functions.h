// Functions.h
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 24 Nov 2021
// Purpose: Function declarations for DataWithStructsReview

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

const string FILENAME = "weather.csv";

struct WeatherDataItem
{
	string date;
	string location;
	float maxTemp;
};
string GetElementFromFile(ifstream& infile);
bool ReadFileIntoArray(WeatherDataItem items[], int& count);
void DisplayWeatherDataItems(WeatherDataItem items[], int count);
int FindMaxTempIndex(WeatherDataItem items[], int count);
#endif // !_FUNCTIONS_H