// Driver.cpp
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 24 Nov 2021
// Purpose: Driver for DataWithStructsReview

#include "Functions.h"
using namespace std;

int main()
{
    //Declare values
    WeatherDataItem items[1000];
    int itemCount = 0;

    //Read file into an array of structs
    if (ReadFileIntoArray(items,itemCount))
    {
        cout << "Successfully opened file" << endl;

        //Display data
        //DisplayWeatherDataItems(items, itemCount);

        //Find greatest element
        int maxTempIndex = FindMaxTempIndex(items, itemCount);
        cout << "Max temp is " << items[maxTempIndex].maxTemp << " which was at " << items[maxTempIndex].location << " on " << items[maxTempIndex].date << endl;
    }
    else
    {
        cout << "Could not open file" << endl;
    }


    return 0;
}