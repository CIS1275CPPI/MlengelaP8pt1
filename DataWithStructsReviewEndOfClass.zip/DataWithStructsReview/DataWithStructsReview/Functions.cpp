// Functions.cpp
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 24 Nov 2021
// Purpose: Function definitions for DataWithStructsReview

#include "Functions.h"
using namespace std;

string GetElementFromFile(ifstream & infile)
{
	string element;
	string discard;
	//Read to first "
	getline(infile, discard, '"');
	//Read in value to next "
	getline(infile, element, '"');
	//Read in ,
	getline(infile, discard, ',');
	return element;
}

bool ReadFileIntoArray(WeatherDataItem items[], int & count)
{
	ifstream infile;
	infile.open(FILENAME);
	if (infile.is_open())
	{
		string element;
		//Discard header row
		getline(infile, element);

		count = 0; //reset count

		while (infile.peek() != EOF)
		{
			//Read one line
			for (int i = 0; i < 2; ++i)
			{
				items[count].date = GetElementFromFile(infile);
			}
			for (int i = 0; i < 6; ++i)
			{
				items[count].location = GetElementFromFile(infile);
			}
			for (int i = 0; i < 2; ++i)
			{
				element = GetElementFromFile(infile);
			}
			items[count].maxTemp = stof(GetElementFromFile(infile));
			//Clear out to the end of the line
			getline(infile, element);
			count++;
		}
		cout << endl << endl;

		return true;
		infile.close();
	}
	else
	{
		return false;
	}
}

void DisplayWeatherDataItems(WeatherDataItem items[], int count)
{
	for (int i = 0; i < count; ++i)
	{
		cout << items[i].date << " " << items[i].location << " " << items[i].maxTemp << endl;
	}
}

//Only returns value not entire line of data <-- not best approach
//float FindMaxTempReturnValue(WeatherDataItem items[], int count)
//{
//	//Start with first value
//	float maxTemp = items[0].maxTemp;
//
//	//Loop through all remaining values
//	for (int i = 1; i < count; ++i)
//	{
//		if (maxTemp < items[i].maxTemp) //Check criteria
//		{
//			maxTemp = items[i].maxTemp;
//		}
//	}
//
//	//Return largest value
//	return maxTemp;
//}

int FindMaxTempIndex(WeatherDataItem items[], int count)
{
	//Start with first value
	int maxTempIndex = 0;

	//Loop through all remaining values
	for (int i = 1; i < count; ++i)
	{
		if (items[maxTempIndex].maxTemp < items[i].maxTemp) //Check criteria
		{
			maxTempIndex = i;
		}
	}

	//Return largest value
	return maxTempIndex;
}