// Functions.h 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 15 Nov 2021
// Purpose: Function Declarations

//Inclusde guard only compile one time
#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <string>
using namespace std;

const int SIZE = 10;

string AskForNameFromUser();
void GetNamesFromUser(string names[], int& rCount);
#endif // !_FUNCTIONS_H
