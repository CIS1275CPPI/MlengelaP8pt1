// Driver.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 15 Nov 2021
// Purpose: demo stuff

#include "Functions.h"
using namespace std;

int main()
{
    //Declare an array to keep names
    string names[SIZE];
    int count;

    //Fill array with names from user
    GetNamesFromUser(names, count);

    //Display names
    for (int i = 0; i < SIZE; ++i)
    {
        cout << names[i] << endl;
    }

    return 0;
}