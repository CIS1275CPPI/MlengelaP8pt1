// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 15 Nov 2021
// Purpose: Function Definitions

#include "Functions.h"
using namespace std;

//Get names from user
void GetNamesFromUser(string names[], int &rCount)
{
	names[0] = "Rob";
	names[1] = "Bjarney";
	names[2] = "Grace";
	names[3] = "Steve";
	names[4] = "Bill";
	rCount = 5;
}

//Ask for your name
string AskForNameFromUser()
{
	string name;
	cout << "Please enter name: ";
	getline(cin, name);
	return name;
}

