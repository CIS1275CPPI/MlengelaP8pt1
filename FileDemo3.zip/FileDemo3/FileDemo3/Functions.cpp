// Functions.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date:8 Nov 2021 
// Purpose: Function definitions for FileDemo3

#include "Functions.h"
using namespace std;

void DisplayHeader()
{
	cout << "Welcome to supper inventory manager 3000!" << endl;
	cout << "The best inventory manager in the multiverse!" << endl;
	cout << endl;
}

void GetInventoryFromUser(vector<InventoryItem>& rItems)
{
	//Start a loop
	do {
		//declare single struct item here
		InventoryItem item;

		//input into the temp struct
		cout << "Description: ";
		getline(cin, item.description);

		//input into the temp struct
		cout << "Quantity: ";
		cin >> item.quantity;
		cin.ignore();

		//input into the temp struct		string location;
		cout << "Location: ";
		getline(cin, item.location);
		
		//input into the temp struct
		cout << "Length: ";
		cin >> item.length;

		cout << "Width: ";
		cin >> item.width;

		cout << "Depth: ";
		cin >> item.depth;

		cout << "Thickness: ";
		cin >> item.thickness;
		cin.ignore();

		cout << "Type: ";
		getline(cin, item.type);

		//push_back the temp struct onto the vector of structs
		rItems.push_back(item);
		
	} while (DoAnother());
}

bool DoAnother()
{
	string doAnother;
	cout << "Do another (y/n)? ";
	getline(cin, doAnother);
	return tolower(doAnother[0]) == 'y';
}

void WriteItemsToFile(string filename, vector<InventoryItem> items)
{
	ofstream myfile(filename);
	if (myfile.is_open())
	{
		//Add header
		myfile <<
			"Description" << "\t" <<
			"Quantity" << "\t" <<
			"Location" << "\t" <<
			"Length" << "\t" <<
			"Width" << "\t" <<
			"Depth" << "\t" <<
			"Thickness" << "\t" <<
			"Type" << endl;
		//Add rows
		for (int i = 0; i < items.size(); ++i)
		{
			myfile <<
				items.at(i).description << "\t" <<
				items.at(i).quantity << "\t" <<
				items.at(i).location << "\t" <<
				items.at(i).length << "\t" <<
				items.at(i).width << "\t" <<
				items.at(i).depth << "\t" <<
				items.at(i).thickness << "\t" <<
				items.at(i).type << endl;
		}
		myfile.close();
	}
	else
	{
		cout << "Unable to open file";
	}
}


void DisplayGoodbye()
{
	cout << "Thank you for using supper inventory manager 3000!" << endl;
}

