// Functions.h 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date:8 Nov 2021 
// Purpose: Function declarations for FileDemo3

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
using namespace std;

struct InventoryItem
{
    string description;
    int quantity;
    string location;
    float length;
    float width;
    float depth;
    float thickness;
    string type;
};

void DisplayHeader();
void GetInventoryFromUser(vector<InventoryItem>& rItems);
void WriteItemsToFile(string filename, vector<InventoryItem> items);
bool DoAnother();
void DisplayGoodbye();

#endif // !_FUNCTIONS_H

