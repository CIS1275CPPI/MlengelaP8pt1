// .cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date:8 Nov 2021 
// Purpose: 

#include "Functions.h"
using namespace std;

int main()
{
    //Declare vectors
    vector<InventoryItem> items;
    //Array format: InventoryItem[10] items2;
    
    //Display header
    DisplayHeader();

    //Get inventory items from user 
    GetInventoryFromUser(items);

    //Write inventory items to file
    WriteItemsToFile("Inventory.txt", items);

    //Open file and read inventory items

    //Display inventory items

    //Say goodbye
    DisplayGoodbye();

    return 0;
}